# v1.2.14
- SeneaL UI repair tooltip: the icon beside "Workbench Lvl: 5" (and Forge / Fletcher-table equivalents) is now the station's own icon, not an item icon.
- Item icons in the repair list are drawn by SeneaL's native row icons, so they sit on their own item lines instead of floating onto the station line.
- Tooltip cache key is content-based (station, items, costs, coins), replacing the random per-open version.

# v1.2.13
- Rebuilt the Thunderstore zip (the 1.2.12 package was rejected). Package layout: every file at the archive root — `manifest.json`, `icon.png`, `README.md`, `CHANGELOG.md`, `RepairRequiresMats.dll`. No subfolders.

# v1.2.12
- Verified against Valheim 1.0.21 (Steam buildid 26249040).
- Faster inventory repair UI: skip rebuilding costs every frame, cache recipes and material rates, use vanilla CountItems/RemoveItem, and avoid per-frame reflection and tooltip tree searches.

# v1.2.11
- Verified against Valheim 1.0.21 (Release build).
- BepInEx dependency set to `denikson-BepInExPack_Valheim-5.4.2360`.

# v1.2.10
- SeneaL UI repair list shows each item's icon to the left of the name

# v1.2.9
- Cannot repair when you have no coins (SeneaL was still using vanilla free repair if our item list was empty)
- SeneaL repair tip is one title, station + coin count, and a readable item/cost list with no duplicated "Nothing to repair"
- Repair spends Azumatt CurrencyPocket coins (same CoinPocket_CoinCount data as that purse) as well as Swmarly Valheim QOL

# v1.2.8
- SeneaL UI repair click now charges coins (it was calling the unpatched vanilla repair method)
- SeneaL repair tip uses plain text so color tags no longer show as `<color=#...>`

# v1.2.7
- Repair hover now shows coin costs again on Valheim 1.0.16 (vanilla UITooltip was overwriting the text every frame)
- Same cost list is written onto SeneaL UI's repair tip, which otherwise keeps its generic "repairs one worn item" message

# v1.2.5
- Repair can spend coins from Swmarly Valheim QOL's Coin Purse as well as coins in inventory
- Damaged items no longer show as Free when the material cost rounds down to 0 (for example a slightly worn Bronze Sword)
- Added Fine Wood to the item-value list (default 1). Wood and Stone default to 1

# v1.2.4
- Default Wood and Stone exchange rates are 1 instead of -1, so wooden/stone gear costs coins to repair

# v1.2.3
- Hide items that cannot be repaired in vanilla (for example torches) from the repair tooltip and repair list
- Contact link updated from Twitter to X

# v1.2.2
- Added Thunderstore AI Generated tag note in the README

# v1.2.1
- Repair uses the vanilla minimum station level; item quality does not raise the bench needed to repair
- Still require the correct station type in Valheim 1.0 so forge gear is not treated as repairable at a workbench
- Recheck crafting-station extensions so removing a bellows or anvil drops the station level immediately
- `CoinOnly = false` charges coins plus original repair materials and lists those materials on the tooltip
- Repair tooltip: white item names, green Free, green/red material amounts, yellow/red coin amounts, red "Needs station" text

# v1.2.0
- Updated for Valheim 1.0
- Fixed MissingMethodException spam for `Player.ConsumeResources(Piece.Requirement[], int, int)`
- Repair now removes coins from inventory directly instead of calling the old ConsumeResources signature
- Look up Coins from ObjectDB instead of the GoldRubyRing/EpicLoot recipe hack
- EpicLoot is optional; still used for extra magic-item repair costs when present
- Updated `Utils.FindChild` for the 1.0 signature
- Repair tooltip now lists items that need a different crafting station instead of showing "Nothing to repair"
- Fixed Stone material using the wrong exchange rate

# v1.1.0
- Removed terminal reload
- Added compatibility for v0.217.46

# v1.0.2 - 2024/4/7
- Passed initial test seems to work. Just remember, an item can only be repaired by the same type of workbench it was created.
- No longer requires the depreciated mod: Extended Item Data Framework

# v1.0.1 - 2024/4/7
- Fixed possible issue with missing assembly files

# v1.0.0 - 2024/4/7
- Moved all configuration to one file: cjayride.RepairRequiresMats-Coins-CJAYCRAFT-fix.cfg

# v0.8.1 - 2024/4/7
- Re-uploaded because package was denied on Thunderstore. No changes to files.

# v0.8.0 - 2024/4/7
- Changed the method in code for text transformation to GetComponent<TMP_Text>() on lines 170 - 172. Committed by "aedenthorn" on Oct 6, 2023.

# v0.7.2 - 2023/7/13
- Added Newtonsoft.Json.dll to the plugins folder, seems to be required for mod to work.

# v0.7.1 - 2023/7/13
- Removed the dependency RandyKnapp-ExtendedItemDataFramework-1.0.11 because it is depreciated (breaks everything) and I believe is no longer needed.

# v0.7.0 - 2023/7/10
- MISTLANDS UPDATE
- Updated dependencies list
- Configuration now allows for easier placement of configuration file. It can be placed anywhere in the BepInEx folder that you specify.
- See cjayride.RepairREquiresMats-Coins-CJAYCRAFT-fix.cfg

# v0.6.4 - 2022/2/23
- Removed the RecipeCusomization dependency and file GoldRubyRing.json because it turns out that this workaround doesn't work on dedicated servers, only on client player run games. So in order to get this to work, you're now required to make sure that the recipes.json file in the EpicLoog plugins folder includes a GoldRubyRing with Coins as a required recipe part like follows:

    {
      "name": "Recipe_GoldRubyRing",
      "item": "GoldRubyRing",
      "craftingStation": "forge",
     "resources": [
	    { "item": "Coins", "amount": 100 },
        { "item": "Bronze", "amount": 4 },
        { "item": "Ruby", "amount": 2 }
      ]
    },

# v0.6.3 - 2022/2/18
- Forgot to include RecipeCustomization mod as dependecy. It's actually not required though so long as you have EpicLoot installed AND your EpicLoot recipe.json file includes a recipe for "Recipe_GoldRubyRing" with Coins as a required resource to craft it. Some servers may want to change the recipe.

# v0.6.2 - 2022/2/18
- Fixed critical bug with dependencies. It been difficult getting this mod on Thunderstore from my community server because I didn't know it relied on so many things.

# v0.6.1 - 2022/2/17
- Removed test code mod config enforcer, because it was incomplete and prohibiting the mod from running at all.

# v0.6.0 - 2022/2/16
- First upload to Thunderstore